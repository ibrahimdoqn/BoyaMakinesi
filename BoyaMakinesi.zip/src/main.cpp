// =============================================
// 2K Akrilik Boya Karışım ve Püskürtme Sistemi
// Arduino Mega 2560 + PlatformIO
//
// Ana Orkestratör - Tüm alt sistemleri koordine eder
// =============================================

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#include "PinConfig.h"

// --- NESNE TANIMLARI ---
LiquidCrystal_I2C lcd(LCD_ADRES, LCD_SUTUN, LCD_SATIR);

// =============================================
// SETUP
// =============================================
void setup() {
    
}


void loop() {

}